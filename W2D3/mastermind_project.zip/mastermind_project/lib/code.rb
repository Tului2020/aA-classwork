class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }
  attr_reader :pegs

  def self.valid_pegs?(arr)
    arr.all? { |element| POSSIBLE_PEGS.keys.join("").downcase.include?(element.downcase) }
  end

  def initialize(arr)
    if Code.valid_pegs?(arr)
      @pegs = arr.join("").upcase.split("")
    else  
      raise "You have entered invalid keys"
    end
  end

  def self.random(length)
    new_arr = []
    length.times { new_arr << POSSIBLE_PEGS.keys.sample }
    Code.new(new_arr)
  end

  def self.from_string(str)
    Code.new(str.split(""))
  end

  def [](i)
    @pegs[i]
  end

  def length
    @pegs.length
  end

  def num_exact_matches(guess)
    count = 0
    @pegs.each_with_index {|ele, i| count += 1 if ele == guess[i]}
    count
  end

  def num_near_matches(guess)
    pegs_hash = Hash.new(0)
    guess_hash = Hash.new(0)
    @pegs.each { |peg| pegs_hash[peg] += 1 }
    guess.pegs.each { |peg| guess_hash[peg] += 1 }
    count = 0
    guess_hash.each do |guess_key, guess_val|
      if pegs_hash.include?(guess_key)
        count += [guess_val, guess_hash[guess_key]].min
      end
    end
    count -= num_exact_matches(guess)
  end

  def ==(guess)
    guess.pegs.join("").upcase == @pegs.join("").upcase
  end





end
