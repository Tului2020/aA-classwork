require_relative "board"
require_relative "human_player"

class Game
    attr_reader :current_player, :player_1_mark, :player_2_mark


    def initialize(player_1_mark, player_2_mark, n = 3)
        @player_1_mark = HumanPlayer.new(player_1_mark)
        @player_2_mark = HumanPlayer.new(player_2_mark)
        @current_player = @player_1_mark
        @board = Board.new(n)
    end

    def switch_turn
        @current_player = (@current_player == @player_1_mark)? @player_2_mark :  @player_1_mark
    end

    def play
        until @board.empty_positions? == 0
            @board.print

            @board.place_mark(@current_player.get_position, @current_player.mark_value)
            
            
            if @board.win?(@current_player.mark_value)
                puts "Victory " + @current_player.mark_value
                break
            else
                switch_turn
            end
        end
        if @board.empty_positions? == 0
            puts "Draw"
        end
        @board.print

    end
end

g = Game.new("X", "T")
g.play




