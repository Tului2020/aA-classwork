class HumanPlayer

    attr_reader :mark_value

    def initialize(mark_value)
        @mark_value = mark_value
    end


    def get_position
        puts "#{@mark_value}, please enter position in this format 'x y'"
        position = gets.chomp.split(" ")
        if position[0].to_i.to_s == position[0] && position[1].to_i.to_s == position[1]
            position[0] = position[0].to_i
            position[1] = position[1].to_i
            return position
        else
            puts "You have entered invalid arguments"
            return get_position
        end 
    end
end






