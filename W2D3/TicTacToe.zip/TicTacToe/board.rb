# add players
# check winner
# print gam board


class Board

    attr_reader :board

    def initialize(n=3)
        @board = Array.new(n) {Array.new(n, '_')} 
    end

    def valid?(position) # position = [x, y]
        position[0] < @board.length && position[1] < @board.length
    end

    def empty?(position)
        @board[position[0]][position[1]] == '_'
    end

    def place_mark(position, mark)
        (!valid?(position) || !empty?(position))? (raise "Please choose another position") : (@board[position[0]][position[1]] = mark)
    end

    def print(board=@board)
        board.each { |row| puts row.join(" ")}
    end

    def win_row?(mark)
        @board.any? { |row| (row.count { |el| el == mark })== @board.length }
    end

    def win_col?(mark)
        @board.transpose.any? { |row| (row.count { |el| el == mark })== @board.length }
    end

    def win_diagonal?(mark)
        d1 = [*0...@board.length].count { |el| @board[el][el] == mark }                 # first diagonal
        d2 = [*0...@board.length].count { |el| @board[el][-1 - el] == mark }            # second diagonal
        d1 == 3 || d2 == 3
    end

    def win?(mark)
        win_row?(mark) || win_col?(mark) || win_diagonal?(mark) 
    end

    def empty_positions?
        @board.flatten.any? {|el| el == "_"}
    end
end

