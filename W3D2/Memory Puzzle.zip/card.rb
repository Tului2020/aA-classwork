# Game class
# Board class
# Card class

class Card
    attr_reader :value
    def initialize(value)
        @value = value
    end

    def reveal
        @value
    end

    def hide
        ""
    end


end

