# Game class
# Board class
# Card class


class Board

    attr_reader :grid, :tracker

    def initialize(num_pairs)
        @num_pairs = num_pairs
        (@row_num, @col_num) = set_size(2 * num_pairs)
        @grid = set_grid
        @tracker = Array.new(@row_num) {Array.new(@col_num, "f")}
    end


    def set_size(n)
        arr = []
        (2...n).each { |i| arr << i if n % i == 0 }
        return [arr[arr.length/2], arr[arr.length/2]] if arr.length.odd?
        arr[(arr.length/2 - 1)..(arr.length/2)]
    end


    def print(matrix=current_board)
        first = ""
        (0...matrix[0].length).each {|idx| first += " " + idx.to_s}
        puts first
        matrix.each_with_index do |row, idx| 
            puts idx.to_s + " " + row.join(" ")
        end
    end


    def valid_pos?(pos)
        (0 <= pos[0] && pos[0] < @row_num) && (0 <= pos[1] && pos[1] < @col_num) #&& pos[0].is_a?(Integer) && pos[1].is_a?(Integer)
        
    end


    def opened?(pos)
        @tracker[pos[0]][pos[1]] == "t"
    end


    def reveal(pos)
        @tracker[pos[0]][pos[1]] = "t"
    end
    

    def hide(pos)
        @tracker[pos[0]][pos[1]] = "f"
    end


    def set_grid
        # create a list to get from
        list = [*'A'.ord...'A'.ord + @num_pairs] * 2
        list.map! { |num| num.chr}

        # choose at random items from previous list 
        grid = Array.new(@row_num) {Array.new([])}
        (0...@row_num).each do |row|
            (0...@col_num).each do |col|
                grid[row] << list.delete_at(rand(list.length))
            end
        end
        grid
    end


    def current_board
        current = Array.new(@row_num) {Array.new(@col_num, "_")}
        (0...@row_num).each do |row|
            (0...@col_num).each do |col|
                current[row][col] = @grid[row][col] if tracker[row][col] == "t"
            end
        end
        current
    end


    def finished?
        tracker.flatten.all? { |el| el == "t"}
    end


end

# board = Board.new(8)

# board.set_to_reveal([0, 0])
# board.set_to_reveal([1, 3])
# board.set_grid


# board.print(board.current_board)


# sleep(1)
# system("clear")
# p Board.factors(100) # ==> [10, 10]
#  n = Board.factors(100)[0] ==> 10   
#  m = Board.factors(100)[1] ==> 10                      

