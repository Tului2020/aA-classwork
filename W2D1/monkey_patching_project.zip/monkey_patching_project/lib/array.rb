# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
    def span
        return nil if self.empty?
        self.max - self.min
    end

    def average
        return nil if self.empty?
        self.sum / self.length.to_f
    end

    def median
        return nil if self.empty?
        return self.sort[self.length / 2] if self.length.odd?
    
        (left = self.sort[self.length / 2 - 1] + right = self.sort[self.length / 2]) / 2.0
    end

    def counts
        count = Hash.new(0)
        self.each { |el| count[el] += 1 }
        count
    end


    def my_count(val)
        count = 0
        self.each { |el| count += 1 if el == val}
        count
    end

    def my_index(val)
        self.each_with_index { |el, idx| return idx if el == val}
        nil
    end
    

    def my_uniq
        hsh = {}
        self.each {|el| hsh[el] = true}
        hsh.keys
    end

    def my_transpose
        new_arr = Array.new(self.length) { Array.new(self.length) }
        [*0...new_arr.length].each do |i|
            [*0...new_arr.length].each do |j|
                new_arr[i][j] = self[j][i]
            end
        end 
        new_arr
    end

end
