# Define your methods here.


def string_map!(str, &prc)
    str.each_char.with_index { |char, idx| str[idx] = prc.call(char)}
end



def three?(arr, &prc)
    arr.count { |el| prc.call(el) } == 3
end


def nand_select(arr, prc1, prc2)
    arr.select { |el| !(prc1.call(el) && prc2.call(el))}
end


def hash_of_array_sum(hsh)
    hsh.values.flatten.sum
end


def abbreviate(str)
    sentence = []
    str.split(" ").each { |word| (word.length > 4)? sentence << remove_vowels(word) : sentence << word}
    sentence.join(" ")
end

def remove_vowels(str)
    vowels = "aeiouAEIOU"
    new_str = ""
    str.each_char { |char| new_str += char if !vowels.include?(char)}
    new_str
end


def hash_selector(hsh, *args)
    new_hsh = Hash.new (0)
    return hsh if args.length ==0
    args.each { |el| new_hsh[el] = hsh[el] if hsh.include?(el)}
    new_hsh
end



