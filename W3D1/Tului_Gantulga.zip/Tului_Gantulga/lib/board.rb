class Board

    attr_reader :size

    # This Board#print method is given for free and does not need to be modified
    # It is used to make your game playable.
    def print
        @grid.each { |row| p row }
    end

    def initialize(size)
        @size = size
        @grid = Array.new(@size) {Array.new(@size)}
    end

    def [](pos)
        @grid[pos[0]][pos[1]]
    end

    def []=(pos, mark)
        @grid[pos[0]][pos[1]] = mark
    end

    def complete_row?(mark)
        @grid.any? { |row| row.uniq == [mark]}
    end


    def complete_col?(mark)
        @grid.transpose.any? { |col| col.uniq == [mark]}
    end

    def complete_diag?(mark)
        diagonals = [[], []]
        (0...@size).each do |idx|
            diagonals[0] << @grid[idx][idx]
            diagonals[1] << @grid[idx][-1 - idx]\
        end
        diagonals.any? { |col| col.uniq == [mark]}
    end

    def winner?(mark)
        complete_col?(mark) || complete_row?(mark) || complete_diag?(mark)
    end






end
