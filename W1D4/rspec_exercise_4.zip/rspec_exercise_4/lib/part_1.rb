def my_reject(arr, &prc)
    rejected = []
    arr.each {|num| rejected << num if !prc.call(num)}
    rejected
end

def my_one?(arr, &proc)
    arr.count {|el| proc.call(el)} == 1
end

def hash_select(hsh, &prc)
    selected_hsh = Hash.new(0)
    hsh.each { |k, v| selected_hsh[k] = v if prc.call(k, v)}
    selected_hsh
end

def xor_select(arr, proc1, proc2)
    xor_select = []
    arr.each { |ele| xor_select << ele if boolean_to_int(proc1.call(ele)) + boolean_to_int(proc2.call(ele)) == 1} 
    xor_select
end

def boolean_to_int(bool)
    bool == true ? 1 : 0
end

def proc_count(num, arr)
    arr.count {|prc| prc.call(num)}
end







