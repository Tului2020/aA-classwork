def element_count(arr)
    ret = Hash.new(0)
    arr.each { |el| ret[el] += 1}
    ret
end


def char_replace!(str, hsh)
    str.each_char.with_index do |char, idx|
        if hsh.include?(char)
            str[idx] = hsh[char]
        end
    end
    str
end

def product_inject(arr)
    arr.inject { |acc, el| acc * el }
end














