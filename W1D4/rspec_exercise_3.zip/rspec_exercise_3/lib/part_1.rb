def is_prime?(num)
    if num < 2
        return false
    end
    (2...num).each do |divisor|
        return false if num  % divisor == 0
    end
    true
end

def nth_prime(num)
    primes = []
    possible_prime = 2
    until primes.length == num
        primes << possible_prime if is_prime?(possible_prime)
        possible_prime += 1
    end
    primes[-1]
end

def prime_range(min, max)
    primes = []
    (min..max).each { |n| primes << n if is_prime?(n)}
    primes
end


# expect(prime_range(4, 17)).to match_array([5, 7, 11, 13, 17])
# expect(prime_range(23, 31)).to match_array([23, 29, 31])
# expect(prime_range(1990, 2000)).to match_array([1993, 1997, 1999])
# expect(prime_range(-10, 1 )).to match_array([])




