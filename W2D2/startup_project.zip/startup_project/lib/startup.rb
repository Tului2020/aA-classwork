require "employee"

class Startup
    attr_reader :name, :funding, :salaries, :employees
    
    def initialize(name, funding, salaries)
        @name = name
        @funding = funding
        @salaries = salaries # {`title` => `salary`}
        @employees = []
    end


    def valid_title?(string)
        @salaries.include?(string)
    end


    def >(str)
        self.funding > str.funding
    end

    def hire(name, title)
        (@salaries.include?(title))? (@employees << Employee.new(name, title)) : (raise "The position does not exist")
    end


    def size
        @employees.length
    end

    def pay_employee(employee)
        pay = @salaries[employee.title]
        if @funding >= pay 
            @funding -= pay
            employee.pay(pay)
        else
            raise "There is not enough funding to employ this candidate"
        end
    end

    def payday
        @employees.each { |employee| pay_employee(employee)}
    end

    def average_salary
        average_salary = 0
        @employees.each{|employee| average_salary += @salaries[employee.title]}
        average_salary / @employees.length.to_f
    end


    def close
        @employees = []
        @funding = 0
    end


    def acquire(startup)
        @funding += startup.funding
        startup.salaries.each { |title, salary| @salaries[title] = salary if !(@salaries.include?(title))}
        startup.employees.each { |startup_employee| @employees << startup_employee }
        startup.close
    end


end
