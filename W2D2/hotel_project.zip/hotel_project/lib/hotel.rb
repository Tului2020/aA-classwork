require_relative "room"

class Hotel

    attr_reader :rooms

    def initialize(name, hsh)
        @name = name
        @rooms = {}
        hsh.each { |name, space| @rooms[name] = Room.new(space) }  
    end

    def name
        @name.split(" ").map { |word| word.capitalize}.join(" ")
    end

    def room_exists?(string)
        @rooms.include?(string)
    end

    def check_in(person, room)
        if !room_exists?(room)
            p 'sorry, room does not exist'
        else
            @rooms[room].add_occupant(person)? (p 'check in successful') : (p 'sorry, room is full')
        end


    end

    def has_vacancy?
        @rooms.any?{ |name, room| room.occupants.length == 0}
    end
        
    def list_rooms
        @rooms.each { |name, room| puts name + " " + room.available_space.to_s}
    end


  
end
