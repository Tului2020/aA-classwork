require 'TDD'
require 'rspec'


describe '#my_uniq' do
    context 'array contains duplicates' do
        it 'returns the array without duplicates' do
            expect([1, 1, 1].my_uniq).to eq([1])
        end
    end
end

describe '#to_sum' do 
    it 'returns an array containing all pairs of indices that sum to zero' do
        expect([1, 3, 4, -3, -4, 7].to_sum).to eq([[1, 3], [2, 4]])
    end

    it 'does not count the same index twice' do 
        expect([0, 1, 2, 3, 4].to_sum).to eq([])
    end
end


describe '#my_transpose' do
    it 'should tranpose a 2D array' do
       expect([[1, 2], [3, 4]].my_transpose).to eq([[1, 3], [2, 4]]) 
    end

    it 'must be an nxn array' do
        expect {[[1, 2], [3]].my_transpose}.to raise_error('non nxn array!')
    end
end

describe '#stock_picker' do
    it 'should give the two most profitable to buy and sell a stock' do
        expect([1, 4, 8, 6, 9, 10, 13, 4, 12].stock_picker).to eq([0,6])
    end

    it 'the buy day cannot be after the sell day' do 
        expect([12, 1, 2].stock_picker).to_not eq([0,1])
    end
end





