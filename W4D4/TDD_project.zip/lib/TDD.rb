class Array

    def my_uniq
        uniq = []
        self.each { |el| uniq << el unless uniq.include?(el)}
        uniq
    end 

    def to_sum
        sums = []

        (0...self.length).each do |i|        
            ((i + 1)...self.length).each do |j|
                sums << [i,j] if self[i] + self[j] == 0
            end
        end
        sums
    end

    def my_transpose
        raise 'non nxn array!' if self.any? { |row| row.length != self.length}


        transpose = Array.new(self.length) {Array.new(self.length, 'nil') }

        (0...self.length).each do |i|
            (0...self.length).each do |j|
                transpose[i][j] = self[j][i]
            end
        end

        transpose
    end

    def stock_picker
        max_profits = [0,1]

        (0...self.length).each do |i|        
            ((i + 1)...self.length).each do |j|
                current_max_profit = (self[max_profits[1]] - self[max_profits[0]]) / self[max_profits[0]]

                potential_max_profit = (self[j] - self[i]) / self[i]

                max_profits = [i,j] if current_max_profit < potential_max_profit
            end
        end

        max_profits
    end

    # use select to get most profitable days 

end

# p [1, 4, 8, 6, 9, 10, 13, 4, 12].stock_picker 


