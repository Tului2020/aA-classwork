def zip(*arrs)
    arrs.transpose()
end


def prizz_proc(arr, prc1, prc2)
    result_array = []
    arr.each { |el| result_array << el if (prc1.call(el) && !prc2.call(el)) || (!prc1.call(el) && prc2.call(el)) }
    result_array
end


def zany_zip(*arrs)
    max_length = 0
    arrs.each {|arr| max_length = [arr.length, max_length].max }
    arrs.each {|arr| (max_length - arr.length).times {arr << nil}}
    arrs.transpose()
end


def maximum(arr, &prc)
    arr.inject { |acc, el| (prc.call(acc) <= prc.call(el))? el : acc }
end


def my_group_by(arr, &prc)
    hash = Hash.new(0)
    arr.each {|el| (hash.include?(prc.call(el)))? (hash[prc.call(el)] << el) : hash[prc.call(el)] = [el]}
    hash
end


def max_tie_breaker(arr, prc1, &prc2)
    arr.inject do |acc, el|
        if prc2.call(acc) < prc2.call(el)
            el
        elsif prc2.call(acc) == prc2.call(el)
            if prc1.call(acc) < prc1.call(el)
                el
            else
                acc
            end
        else
            acc
        end
    end
end


def silly_syllables(str)
    sentence = []
    vowels = 'aeiou'
    str.split(' ').each do |word|
        vowel_index = []
        word.each_char.with_index {|char, idx| vowel_index << idx if vowels.include?(char) }
        (vowel_index.length >= 2)? (sentence << word[vowel_index[0]..vowel_index[-1]]) : (sentence << word)
    end
    sentence.join(' ')
end
