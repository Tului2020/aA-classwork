def partition (arr,num)
    new_arr = [[], []]
    arr.each {|el| (el < num)? (new_arr [0] << el) : (new_arr[1] << el)} 
    new_arr
end


def merge(hash1, hash2)
    new_hash = Hash.new(0)
    hash2.each { |el, val| new_hash[el] += val}
    hash1.each { |el, val| new_hash[el] = val if !new_hash.include?(el)}
    new_hash
end


def censor(str, arr)
    words = str.split(" ")
    new_str = []
    words.each { |word| (arr.include?(word.downcase))? (new_str << vowel_replace(word)) : (new_str << word)}
    new_str.join(" ")
end
def vowel_replace(str)
    new_word = ""
    str.each_char { |char| ("aeiou".include?(char.downcase))? (new_word << "*") : (new_word << char)}
    new_word
end


def power_of_two?(num)
    Math.log2(num).round == Math.log2(num)
end




