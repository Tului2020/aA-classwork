def palindrome?(str)
    (0..str.length/2).each do |i|
        if str[i] != str[-1 - i]
            return false
        end
    end
    true
end


def substrings(str)
    new_array  = []
    str.each_char.with_index { |char, idx| new_array << put_words(str[idx..])}
    new_array.flatten
end
def put_words(str)
    new_array = [""]
    str.split("").map { |char| new_array << new_array[-1] + char }
    new_array.delete_at(0)
    new_array
end


def palindrome_substrings(str)
    new_array = []
    combo = substrings(str)
    combo.each { |substring| new_array << substring if palindrome?(substring) && substring.length > 1 }
    new_array
end

