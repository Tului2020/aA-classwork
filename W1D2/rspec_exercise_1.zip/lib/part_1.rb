def average(num1, num2)
    (num1 + num2) / 2.0
end

def average_array(arr)
    arr.inject { |acc, el| acc + el } / arr.length.to_f
end

def repeat(str, num)
    str * num
end

def yell(str)
    str.upcase + "!"
end

def alternating_case(str)
    temp = str.split(" ")
    ret = []
    (0...temp.length).each do |i|
        if i % 2 == 0
            ret << temp[i].upcase
        else
            ret << temp[i].downcase
        end
    end
    ret.join(" ")
end


