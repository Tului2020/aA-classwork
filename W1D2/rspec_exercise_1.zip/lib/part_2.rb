def hipsterfy(str)
    vowels = "aeiou"
    (1..str.length).each do |i|
        if vowels.include?(str[-i])
            return str[0...str.length-i] + str[str.length-i+1...str.length]
        end
    end
    str
end

def vowel_counts(str)
    vowels = "aeiou"
    count = Hash.new(0)
    str.each_char { |char| count[char.downcase] += 1 if vowels.include?(char.downcase) }
    count
end

def caesar_cipher(str, num)
    ret = ""
    str.each_char do |char|
        if 96 < char.ord && char.ord < 123 
            ret << ((char.ord + num - 97) % 26 + 97).chr
            
        else
            ret << char
        end
        end
    ret
end


