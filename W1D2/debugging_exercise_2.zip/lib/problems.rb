# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.


def largest_prime_factor(num)
    factors = []
    (2..num).each { |n| factors << n if prime?(n) && num % n == 0 }
    factors[-1]
end

def prime?(num)

    return false if num < 2


    (2...num).each do |factor|
        if num % factor == 0
            return false
        end
    end

    return true
end


def unique_chars?(str)
    count = Hash.new(0)
    str.each_char { |char| count[char] += 1 }
    count.max_by{|letter, ct| ct}[1] <= 1
end


def dupe_indices(arr)
    #p arr.select {|char| char == "b"}
    #p arr.index("b")


    count = Hash.new(0)
    arr.each { |el| count[el] += 1}
    indices = Hash.new []
    arr.each_with_index { |el, i| indices[el] += [i] if count[el] > 1 }
    indices
end


def ana_array(arr1, arr2)
    arr1_hash = Hash.new(0)
    arr2_hash = Hash.new(0)
    arr1.each { |el| arr1_hash[el] += 1 }
    arr2.each { |el| arr2_hash[el] += 1 }
    arr1_hash == arr2_hash
end
